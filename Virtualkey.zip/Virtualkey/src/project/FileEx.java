package project;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class FileEx {
	public static void main(String[] args) throws IOException {
		String path="D:\\fil\\";
		Scanner sc=new Scanner(System.in);
		int i,c;
		File f = new File(path);
		int y;
		do
		{
			System.out.println("MENU");
			System.out.println("DISPLAY");
			System.out.println("ADD,DELETE SEARCH");
			System.out.println("EXIT");
			c=sc.nextInt();
		switch(c)
		{
		case 1:
			File filenames[]=f.listFiles();
			for(File ff:filenames) 
			{
				System.out.println(ff.getName());
			}
			break;
		case 2:
			System.out.println("Enter choice to 1.add, 2.delete 3.search");
			int ch=sc.nextInt();
			switch(ch)
			{
			case 1:
			System.out.println("enter the filename");
			String filename=sc.next();
			String finalpath=path+filename;
			f=new File(finalpath);
		//create a new file
			boolean b=f.createNewFile();
			if(b!=true) {
			System.out.println("file not created");
			}
			else {
			System.out.println("file created");
			}
			break;
			case 2:
			System.out.println("enter the filename");
			String fname=sc.next();
			String fp=path+fname;
			f=new File(fp);
			//delete operation
			f.delete();
			break;
			case 3:
				System.out.println("enter the filename to search");
				String fme=sc.next();
				 f=new File(path);
				//display operation
				int flag=0;
				File fil[]=f.listFiles();
				for(File ff:fil) {
					if(ff.getName().equals(fme)) {
						flag=1;
						break;
					}
					else {
						flag=0;
					}
				
				}
				
				if(flag==1) {
					System.out.println("file is found");
				}
				else {
					System.out.println("file is not found");
				}
				break;
			}
		}
	 y=sc.nextInt();
		}while(y==1);

	}

}

